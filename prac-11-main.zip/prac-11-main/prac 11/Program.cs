﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prac_11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Задача 1.Определить количество элементов одномерного массива.
            //int[] omas = { 1, 2, 3, 4, 5 };
            //Console.WriteLine($"размер: {omas.Length}");

            //Задача 2.Обнулить заданный диапазон элементов в одномерном массиве.
            //int[] omas = { 1, 2, 3, 4, 5 };
            //Console.WriteLine("массив");
            //for (int i = 0; i < omas.Length; i++)
            //{
            //    Console.WriteLine($"omas[{i}] = {omas[i]}");
            //}
            //Array.Clear(omas, 2, 2);
            //Console.WriteLine("обнуленный массив");
            //for (int i = 0; i < omas.Length; i++)
            //{
            //    Console.WriteLine($"omas[{i}] = {omas[i]}");
            //}

            //Задача 3.Найти максимальное и минимальное значение в массиве.
            //int[] omas = { -1, 2, -3, 4, -5 };
            //int max = omas.Max();
            //int min = omas.Min();
            //Console.WriteLine($"min = {min}, max = {max}");

            //Задача 4.Сортировка массива по возрастанию.
            //int[] omas = { -1, 2, -3, 4, -5 };
            //Array.Sort(omas);
            //foreach (int i in omas)
            //{
            //    Console.WriteLine(i);
            //}

            //Задача 5.Реверс массива.
            //int[] omas = { -1, 2, -3, 4, -5 };
            //Array.Reverse(omas);
            //foreach (int i in omas)
            //{
            //    Console.WriteLine(i);
            //}

            //Задача 6. Подсчет количества вхождений определенного числа в массив.
            //int[] omas = { 1, 2, 3, 4, 5, 2, 2, 6, 7, 2 };
            //Console.Write("Введите число для подсчета: ");
            //int i = int.Parse(Console.ReadLine());
            //int count = Array.FindAll(omas, x => x == i).Length;
            //Console.WriteLine($"Число {i} встречается {count} раза в массиве.");

            //Задача 7.Поиск элемента по условию.

            //Задача 8. Изменение размера массива.
            //int[] omas = { -1, 2, -3, 4, -5 };
            //Array.Resize(ref omas,10);
            //foreach (int el in omas)
            //{
            //    Console.WriteLine(el);
            //}

            //Задача 9.Поиск индекса элемента.
            //int[] array = { 10, 20, 30, 40, 50, 60 };
            //Console.Write("Введите число для поиска индекса: ");
            //int n = int.Parse(Console.ReadLine());
            //int index = Array.FindIndex(array, x => x == n);
            //if (index >= 0)
            //    Console.WriteLine($"Индекс элемента {n}: {index}");
            //else
            //    Console.WriteLine("Элемент не найден.");

            //Задача 10.Удаление всех четных элементов из массива.



            //Задача 11.Сумма всех элементов массива.

            //Задача 12.Умножение всех элементов массива на определенное число.


        }
    }
}
